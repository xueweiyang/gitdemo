package com.alibaba.android.arouter.facade.template;

/**
 * Store policy.
 *
 * @author Alex <a href="mailto:zhilong.liu@aliyun.com">Contact me.</a>
 * @version 1.0
 * @since 16/8/24 10:15
 */
@Deprecated
public interface IPolicy {
    int getFlag();
}
