# ActivityTemple
Android MVP Activity Temple
powered by `FreeMarker`
