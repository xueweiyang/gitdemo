# AllocRecordDemo
A demo to show how to get the allocated objects information in android


for the detail of this project, please read this post: [http://ragnraok.github.io/get_android_alloc_object_info.html](http://ragnraok.github.io/get_android_alloc_object_info.html)
