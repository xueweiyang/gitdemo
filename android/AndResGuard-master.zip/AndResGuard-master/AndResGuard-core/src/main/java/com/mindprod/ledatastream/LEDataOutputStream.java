/**
 * Description:
 * LEDataOutputStream.java Create on 2014-5-14
 *
 * @author shaowenzhang <shaowenzhang@tencent.com>
 * @version 1.0
 *     Copyright (c) 2014 Tecent WXG AndroidTeam. All Rights Reserved.
 */
package com.mindprod.ledatastream;

import java.io.OutputStream;

public class LEDataOutputStream extends LittleEndianDataOutputStream {

  public LEDataOutputStream(OutputStream out) {
    super(out);
    // TODO Auto-generated constructor stub
  }
}
