### Umeng sdk
```
"R.anim.umeng*",
"R.string.umeng*",
"R.string.UM*",
"R.string.tb_*",
"R.layout.umeng*",
"R.layout.socialize_*",
"R.layout.*messager*",
"R.layout.tb_*",
"R.color.umeng*",
"R.color.tb_*",
"R.style.*UM*",
"R.style.umeng*",
"R.drawable.umeng*",
"R.drawable.tb_*",
"R.drawable.sina*",
"R.drawable.qq_*",
"R.drawable.tb_*",
"R.id.umeng*",
"R.id.*messager*",
"R.id.progress_bar_parent",
"R.id.socialize_*",
"R.id.webView"
```
### google-services
```
"R.string.google_app_id",
"R.string.gcm_defaultSenderId",
"R.string.default_web_client_id",
"R.string.ga_trackingId",
"R.string.firebase_database_url",
"R.string.google_api_key",
"R.string.google_crash_reporting_api_key"
```
### getui(个推)
```
"R.drawable.push",
"R.drawable.push_small",
"R.layout.getui_notification"
```

### JPush(极光推送)
```
"R.drawable.jpush_notification_icon"
```

### GrowingIO
```
"R.string.growingio_project_id",
"R.string.growingio_url_scheme",
"R.string.growingio_channel"
```

### Firebase
#### [firStore](https://firebase.google.cn/docs/firestore/)
```
R.string.project_id
```

### Huawei push
```
R.string.hms_update_title
```
