# TagTextView
TextView with tag

_ _ _

[imagespan 居中的正确办法](http://www.cnblogs.com/withwind318/p/5541267.html)
### 0.1 版本

* 基本效果实现

_ _ _ 

### 使用方法

```
    <com.tagtextview.lib.TagTextView
        android:id="@+id/tagText"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="我来测试测试!@测试"
        android:maxLines="2"
        android:textSize="22dp"
        />
        
        tagTextView.render();
```



![效果图](https://github.com/Guolei1130/TagTextView/blob/master/ScreenShot/Screenshot_2016-10-22-13-23-51-153_com.gl.png)

