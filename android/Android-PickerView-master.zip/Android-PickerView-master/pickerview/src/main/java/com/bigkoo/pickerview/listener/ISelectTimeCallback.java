package com.bigkoo.pickerview.listener;

/**
 * Created by zengsong on 2018/3/21.
 */

public interface ISelectTimeCallback {

    public void onTimeSelectChanged();
}
