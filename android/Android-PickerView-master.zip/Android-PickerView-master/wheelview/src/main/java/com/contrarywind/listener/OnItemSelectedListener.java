package com.contrarywind.listener;


public interface OnItemSelectedListener {
    void onItemSelected(int index);
}
