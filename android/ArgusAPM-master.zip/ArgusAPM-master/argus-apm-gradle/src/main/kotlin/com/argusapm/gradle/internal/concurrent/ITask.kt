package com.argusapm.gradle.internal.concurrent

import java.util.concurrent.Callable

interface ITask : Callable<Any>