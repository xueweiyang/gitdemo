package com.argusapm.gradle.internal.cutter

class InputSourceFileStatus {
    var isAspectChanged = false
    var isIncludeFileChanged = false
    var isExcludeFileChanged = false
}