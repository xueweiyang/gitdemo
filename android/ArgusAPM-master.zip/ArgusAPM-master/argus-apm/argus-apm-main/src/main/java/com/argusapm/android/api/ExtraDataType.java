package com.argusapm.android.api;

/**
 * @author ArgusAPM Team
 */
public class ExtraDataType {
    public static final int TYPE_GET_PLUGIN_NAME = 0;
    public static final int TYPE_GET_PLUGIN_VERSION = 1;
    public static final int TYPE_GET_MAIN_VERSION = 2;
    public static final int TYPE_RECV_V5_UPDATE = 3;
}
