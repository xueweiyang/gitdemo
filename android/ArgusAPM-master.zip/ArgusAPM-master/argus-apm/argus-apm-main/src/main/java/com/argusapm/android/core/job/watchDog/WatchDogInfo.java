package com.argusapm.android.core.job.watchDog;

import com.argusapm.android.core.job.block.BlockInfo;

/**
 * @author ArgusAPM Team
 */
public class WatchDogInfo extends BlockInfo {
    private final String SUB_TAG = "WachDogInfo";
}
