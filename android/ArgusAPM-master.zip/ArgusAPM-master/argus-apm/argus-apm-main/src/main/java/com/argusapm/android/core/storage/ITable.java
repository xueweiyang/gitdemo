package com.argusapm.android.core.storage;

/**
 * @author ArgusAPM Team
 */
public interface ITable {

    String createSql();

    String getTableName();

}