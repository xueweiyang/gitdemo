package com.argusapm.android.debug.callback;

/**
 * Debug模块回调接口
 *
 * @author ArgusAPM Team
 */
public interface IDebugCallback {

}
