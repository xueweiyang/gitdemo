package com.argusapm.android.debug.tasks;

import com.argusapm.android.core.IInfo;

/**
 * @author ArgusAPM Team
 */
public interface IParser {
    boolean parse(IInfo info);
}
