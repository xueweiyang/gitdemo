package com.argusapm.android.utils;

/**
 * @author ArgusAPM Team
 */
public class AspectjUtils {
    public static final String JOINPOINT_KIND_CALL_METHOD = "method-call";
    public static final String JOINPOINT_KIND_EXECUTION_METHOD = "method-execution";
    public static final String JOINPOINT_KIND_CALL_CONSTRUCTOR = "constructor-call";
    public static final String JOINPOINT_KIND_EXECUTION_CONSTRUCTOR = "constructor-execution";

}
