package com.argusapm.android.okhttp3;

/**
 * @author ArgusAPM Team
 */
public class Env {

    /**
     * the tag
     */
    public static final String TAG = "NetWorkInterceptor";

    public static final boolean DEBUG = false;
}