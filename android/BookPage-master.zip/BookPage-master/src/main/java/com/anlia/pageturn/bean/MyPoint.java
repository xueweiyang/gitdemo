package com.anlia.pageturn.bean;

/**
 * Created by anlia on 2017/10/19.
 */

public class MyPoint {
    public float x,y;

    public MyPoint(){}

    public MyPoint(float x, float y){
        this.x = x;
        this.y = y;
    }
}
