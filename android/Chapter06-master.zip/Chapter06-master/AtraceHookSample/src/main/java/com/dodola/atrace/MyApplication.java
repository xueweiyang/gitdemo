
package com.dodola.atrace;

import android.app.Application;

/**
 * Created by dodola on 2018/12/11.
 */
public class MyApplication extends Application {


    @Override
    public void onCreate() {
        super.onCreate();

    }
}
