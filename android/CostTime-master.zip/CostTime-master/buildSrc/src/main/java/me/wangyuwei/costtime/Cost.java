package me.wangyuwei.costtime;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 巴掌
 * https://github.com/JeasonWong
 */

@Target(ElementType.METHOD)
public @interface Cost {
}
