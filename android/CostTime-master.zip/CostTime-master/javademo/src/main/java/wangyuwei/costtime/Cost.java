package wangyuwei.costtime;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Created by bazhang on 2017/3/1.
 */
@Target(ElementType.METHOD)
public @interface Cost {
}
