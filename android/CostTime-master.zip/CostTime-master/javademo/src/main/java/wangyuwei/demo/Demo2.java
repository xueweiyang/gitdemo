package wangyuwei.demo;

/**
 * Created by bazhang on 2017/3/1.
 */
public class Demo2 {

    public static void main(String[] args) {
        System.out.println();
        Any any = new Any();
        any.show();
        System.out.println("my age is : " + any.getAge());
    }


}
