---
name: Bug report
about: Create a report to help us improve

---

**什么jzvd版本

**是否和安卓版本有关系，什么版本

**是否和特定品牌的手机机型有关系，什么机型

**相关log是什么

**复现流程

**最好有截图或者视频说明情况
