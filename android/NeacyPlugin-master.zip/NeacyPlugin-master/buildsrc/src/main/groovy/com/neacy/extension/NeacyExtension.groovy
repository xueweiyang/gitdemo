package com.neacy.extension

import org.gradle.api.Project

/**
 * 配置
 */
public class NeacyExtension {
    boolean debugOn = true

    public NeacyExtension(Project project) {

    }
}