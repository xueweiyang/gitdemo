package com.neacy.extension

import org.gradle.api.Project

class NeacyPlaceExtension {

    File[] files = null

    public NeacyPlaceExtension(Project project) {

    }
}