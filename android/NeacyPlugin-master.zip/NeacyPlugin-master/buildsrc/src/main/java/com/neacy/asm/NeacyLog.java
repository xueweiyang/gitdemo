package com.neacy.asm;

/**
 * @author yuzongxu <yuzongxu@xiaoyouzi.com>
 * @since 2017/11/6
 */
public class NeacyLog {

    public static void log(String msg) {
        System.out.println(msg);
    }
}
