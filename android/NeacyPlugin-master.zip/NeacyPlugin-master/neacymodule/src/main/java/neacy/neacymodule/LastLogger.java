package neacy.neacymodule;

import android.util.Log;

/**
 * @author yuzongxu <yuzongxu@xiaoyouzi.com>
 * @since 2017/12/20
 */
public class LastLogger {

    public static void printLog() {
        Log.w("Jayuchou", "=== 这是旧的Logger ===");
    }
}
