package com.base;

import java.io.Serializable;

/**
 * Created by baixiaokang on 17/1/24.
 */

public interface BaseBean extends Serializable {
    String getObjectId();
}
