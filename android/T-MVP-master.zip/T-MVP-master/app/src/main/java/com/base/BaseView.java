package com.base;

/**
 * Created by baixiaokang on 16/4/22.
 */
public interface  BaseView {
}
