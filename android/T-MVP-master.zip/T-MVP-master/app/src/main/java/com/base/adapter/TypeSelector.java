package com.base.adapter;

/**
 * Created by baixiaokang on 16/12/30.
 */

public interface TypeSelector<M> {
    int getType(M m);
}
