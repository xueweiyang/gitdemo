package com.base.entity;

/**
 * Created by baixiaokang on 16/5/5.
 */
public class CreatedResult {
    public String createdAt;
    public String objectId;
    public String url;
}
