package com.base.entity;

/**
 * Created by baixiaokang on 16/12/28.
 */

public class Face {
    String face;

    public Face(String f) {
        this.face = f;
    }
}

