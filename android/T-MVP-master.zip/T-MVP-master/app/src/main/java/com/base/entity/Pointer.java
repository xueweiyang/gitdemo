package com.base.entity;

/**
 * Created by baixiaokang on 16/5/4.
 *
 */
public class Pointer {
    String __type = "Pointer";
    String className;
    String objectId;

    public Pointer(String className, String objectId) {
        this.className = className;
        this.objectId = objectId;
    }
}
