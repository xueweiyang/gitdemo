package android.content.res;

/**
 * Created by qiaopu on 2018/5/18.
 */
public class ResourcesImpl {

}
