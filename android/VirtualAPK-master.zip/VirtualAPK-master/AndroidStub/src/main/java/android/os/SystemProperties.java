package android.os;

/**
 * @author johnsonlee
 */
public class SystemProperties {

    public static String get(final String key) {
        throw new RuntimeException("Stub!");
    }

    public static String get(final String key, final String def) {
        throw new RuntimeException("Stub!");
    }

    public static int getInt(final String key, final int def) {
        throw new RuntimeException("Stub!");
    }

    public static long getLong(final String key, final long def) {
        throw new RuntimeException("Stub!");
    }

    public static boolean getBoolean(final String key, final boolean def) {
        throw new RuntimeException("Stub!");
    }

    public static void set(final String key, final String val) {
        throw new RuntimeException("Stub!");
    }

    public static void addChangeCallback(final Runnable callback) {
        throw new RuntimeException("Stub!");
    }
}
