package com.android.internal;

/**
 * @author johnsonlee
 */
public final class R {

    public static final class id {

        public static int action0 = 0;

        public static int actions = 0;

        public static int action_divider = 0;

        public static int big_picture = 0;

        public static int big_text = 0;

        public static int big_text2 = 0;

        public static int chronometer = 0;

        public static int icon = 0;

        public static int inbox_text0 = 0;

        public static int inbox_text1 = 0;

        public static int inbox_text2 = 0;

        public static int inbox_text3 = 0;

        public static int inbox_text4 = 0;

        public static int inbox_text5 = 0;

        public static int inbox_text6 = 0;

        public static int inbox_end_pad = 0;

        public static int info = 0;

        public static int line1 = 0;

        public static int line3 = 0;

        public static int overflow_divider = 0;

        public static int progress = 0;

        public static int title = 0;

        public static int text = 0;

        public static int text2 = 0;

        public static int time = 0;

        public static int right_icon = 0;

        public static int fillInIntent = 0;

        public static int status_bar_latest_event_content = 0;
    }

}
