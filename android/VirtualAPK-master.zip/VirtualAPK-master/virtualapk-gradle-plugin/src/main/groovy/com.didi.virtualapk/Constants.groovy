package com.didi.virtualapk

public final class Constants {
    public static final String GRADLE_3_1_0 = 'va.gradle.3.1.0'
}