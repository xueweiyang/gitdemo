package com.didi.virtualapk.aapt

/**
 * enum from include/androidfw/ResourceTypes.h
 */
public final class ResStringPoolSpan {

    public static final int END = 0xFFFFFFFF

    public static final byte[] END_SPAN = [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF]

}