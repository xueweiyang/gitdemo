package com.didi.virtualapk.aapt

/**
 * enum from include/androidfw/ResourceTypes.h
 */
public final class ResTableType {

    public static final int NO_ENTRY = -1;

}
