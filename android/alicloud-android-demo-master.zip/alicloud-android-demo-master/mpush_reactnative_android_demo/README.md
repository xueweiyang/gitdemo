## MPush ReactNative Demo
本工程是在ReactNative环境下接入阿里云移动推送Android SDK的demo工程,具体的集成方式可以参考:[阿里云移动推送+ReactNative最佳实践](https://help.aliyun.com/document_detail/53574.html?spm=5176.product30047.6.654.J2kuze)

### 1. 使用方法
- 在工程目录下运行"npm install"指令,安装依赖模块
- 依赖模块安装完成后运行"react-native run-android"启动工程
