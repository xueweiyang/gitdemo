abstract class BannerWithEval{
  get bannerUrl;
}