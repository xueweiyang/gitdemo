package fastdex.runtime;

/**
 * Created by tong on 17/3/15.
 */
public class AntilazyLoad {
    public static String str = "";
}