package fastdex.sample;

/**
 * Created by tong on 17/11/14.
 */
public class ImplementTest extends ParentClass implements InterfaceTest {

}
