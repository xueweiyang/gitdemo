package fastdex.sample;

import android.app.Activity;
import android.os.Bundle;

import com.github.typ0520.fastdex.sample.R;

public class LoginActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
}
