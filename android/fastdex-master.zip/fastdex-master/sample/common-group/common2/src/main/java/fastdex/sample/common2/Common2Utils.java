package fastdex.sample.common2;

/**
 * Created by tong on 17/4/13.
 */
public class Common2Utils {
    public static String str = Common2Utils.class.getSimpleName() + ".str哈1";

    public Common2Utils() {
    }
}
