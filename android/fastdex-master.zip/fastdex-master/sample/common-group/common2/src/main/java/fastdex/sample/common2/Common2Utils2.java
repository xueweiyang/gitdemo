package fastdex.sample.common2;

/**
 * Created by tong on 17/4/13.
 */
public class Common2Utils2 {
    public static String str = "123";
}
