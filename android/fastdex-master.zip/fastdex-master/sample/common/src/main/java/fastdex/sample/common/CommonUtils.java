package fastdex.sample.common;

/**
 * Created by tong on 17/4/13.
 */
public class CommonUtils {
    public static String str = CommonUtils.class.getSimpleName() + ".str0";

    public CommonUtils() {

        new C3XXXX();
    }

    public static class C3XXXX {

    }
}
