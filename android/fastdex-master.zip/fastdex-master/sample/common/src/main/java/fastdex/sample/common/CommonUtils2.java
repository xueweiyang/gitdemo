package fastdex.sample.common;

/**
 * Created by tong on 17/4/13.
 */
public class CommonUtils2 {
    public static String str = CommonUtils2.class.getSimpleName() + ".str";
}
