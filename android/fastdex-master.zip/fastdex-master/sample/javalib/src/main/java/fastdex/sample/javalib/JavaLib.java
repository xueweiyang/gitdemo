package fastdex.sample.javalib;

/**
 * Created by tong on 17/4/14.
 */
public class JavaLib {
    public static String str = JavaLib.class.getSimpleName() + ".str";

    public JavaLib() {

    }
}
