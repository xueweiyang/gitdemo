package fastdex.sample.javalib;

/**
 * Created by tong on 17/8/25.
 */

public class Main {
    public static void main(String[] args) {
    }
}
