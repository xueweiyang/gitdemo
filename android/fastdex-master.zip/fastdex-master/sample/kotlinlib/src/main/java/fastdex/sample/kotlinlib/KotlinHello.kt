package fastdex.sample.kotlinlib

class KotlinHello {
    var name: String = "hello-kotlin"
}