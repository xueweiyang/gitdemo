import 'package:flutter/material.dart';

class StatusScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Center(
      child: new Text(
        "Status",
        style: new TextStyle(fontSize: 20.0),
      ),
    );
  }
}
