package com.silencedut.fpsviewer;

/**
 * @author SilenceDut
 * @date 2019/5/7
 */
public class FpsConfig {
    public static FpsConfig defaultConfig(){
        return new FpsConfig();
    }
}
