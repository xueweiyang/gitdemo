package com.silencedut.fpsviewer.transfer

import com.silencedut.hub.IHub

/**
 * @author SilenceDut
 * @date 2019/5/5
 */
interface ITransfer : IHub