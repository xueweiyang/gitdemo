rm -f parse.h parse.h.temp keywordhash.h parse.c lemon mkkeywordhash parse.out
